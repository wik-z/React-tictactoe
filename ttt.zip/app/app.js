var React = require('react');
var ReactDOM = require('react-dom');

//Require Game components
var Game = require('./components/game');
var Login = require('./components/login');

var App = React.createClass({
	getInitialState: function() {
		return {
			play: false,
			players: [
				"One",
				"Two"
			]
		}
	},

	startGame: function(plr1, plr2) {
		document.getElementById('login').setAttribute('class', 'logged');
		setTimeout(() => this.setState({
			play: true,
			players: [
				plr1,
				plr2
			]
		}), 550);
	},

	render: function() {
		var contents = (this.state.play == true ? <Game players={this.state.players} /> : <Login startg={this.startGame} />);
		return (
			<div id="app">
				{contents}
			</div>
		);
	}


});

ReactDOM.render(<App />, document.getElementById('root'))