var React = require('react');

var Reset = React.createClass({
	render: function() {
		return <button onClick={this.props.click}>RESET</button>
	}
});

module.exports = Reset;